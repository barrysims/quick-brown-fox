#include "StringAction.h"

extern void printKey(char val);

void StringAction::activate(elapsedMillis time) {
    //printKey(val);
    for(int i = n - 1; i >= 0; i--) {
        char c = *(val + i);
        printKey(c);
    }
    Action::activate(time);
}
